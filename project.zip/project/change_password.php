 <?php
$con = mysqli_connect("localhost","root","","hostel");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();
?> 
        
		<head>
		    <title>Admin Panel</title>
		    <meta name="viewport" content="width=device-width, initial-scale=1">
		  
			<link rel="stylesheet" href="css/custom1.css">
			<link rel="stylesheet" href="css/bootstrap.min.css">
			<script src="js/jquery.min.js"></script>
			<script src="js/bootstrap.min.js"></script>
		    
		</head>
		<?php if(isset($_SESSION['user_id']))
		{   ?>
				<body class="body_style">
					
					<div id="header">
					<center> 
					    <img src="img/logo2.png" class="logo1" />
					    <h2 class="admin_txt">Change Password</h2>
					</center>
					

					</div>

					<div id="sidebar">
					<ul>
						
						<a href="" style="text-decoration:none; color:white;"> <li>Update Data</li> </a>
						<a href="change_password.php" style="text-decoration:none; color:white;"> <li>Change Password</li> </a>
						<a href="logout.php" style="text-decoration:none; color:white;"><li>Logout</li></a> 
					</ul>

					</div>

					<div id="data">
                    <?php   
					?>
					
						<div class="row">
						<div class="col-sm-12">
						<h1>Change Password</h1>
						</div>
						</div>
						<div class="row">
						<div class="col-sm-6 col-sm-3">
						<p class="text-center">Use the form below to change your password. Your password cannot be the same as your username.</p>
						<form method="post" id="passwordForm">
						<input type="password" class="input-lg form-control" name="password1" id="password1" placeholder="New Password" autocomplete="off">
						<div class="row">
						<div class="col-sm-6">
						<span id="8char" class="glyphicon glyphicon-remove" style="color:#FF0004;"></span> 8 Characters Long<br>
						<span id="ucase" class="glyphicon glyphicon-remove" style="color:#FF0004;"></span> One Uppercase Letter
						</div>
						<div class="col-sm-6">
						<span id="lcase" class="glyphicon glyphicon-remove" style="color:#FF0004;"></span> One Lowercase Letter<br>
						<span id="num" class="glyphicon glyphicon-remove" style="color:#FF0004;"></span> One Number
						</div>
						</div>
						<input type="password" class="input-lg form-control" name="password2" id="password2" placeholder="Repeat Password" autocomplete="off">
						<div class="row">
						<div class="col-sm-12">
						<span id="pwmatch" class="glyphicon glyphicon-remove" style="color:#FF0004;"></span> Passwords Match
						</div>
						</div>
						<input type="submit" class="col-xs-12 btn btn-primary btn-load btn-lg" data-loading-text="Changing Password..." value="Change Password">
						</form>
						</div><!--/col-sm-6-->
						</div><!--/row-->
						

					</div>
					
				</body>
		    <?php
		}
			?>
	