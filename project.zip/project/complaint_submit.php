 <?php




$con = mysqli_connect("localhost","root","","hostel");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();



?> 
<?php

		$name =   $_POST['name'];
		$email =  $_POST['email'];
		$mobile = $_POST['mobile'];
		$room_no = $_POST['room_no'];
		$comp = $_POST['comp_regard'];
		$msg = $_POST['message'];

		$query = "INSERT INTO `complaint`(`name`, `email`, `mobile`, `room_no`, `complaint_regard`, `complaint`) VALUES ('$name', '$email', '$mobile', '$room_no','$comp','$msg');";

		$submit = mysqli_query($con,$query);
        
		if($submit){
			
			echo "Complaint Subitted";
		}else{
			
			echo "Not Submitted";
		}
?>