
$(document).ready(function (l){
$("#form1").on('submit',(function(l){
l.preventDefault();
$.ajax({
url: "upload.php",
type: "POST",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,	
success: function(data){
	$("#error2").html(data);
	if(!data){
	$("#file_upload").hide(this);
	}
},
error: function(){} 	        
});
}));
});
$(document).ready(function ()
    { 
		$('#characterLeft').text('140 characters left');
			$('#message').keydown(function () 
			{
					var max = 140;
					var len = $(this).val().length;
					if (len >= max) 
					{
						$('#characterLeft').text('You have reached the limit');
						$('#characterLeft').addClass('red');
						$('#btnSubmit').addClass('disabled');            
					} 
					else 
					{
						var ch = max - len;
						$('#characterLeft').text(ch + ' characters left');
						$('#btnSubmit').removeClass('disabled');
						$('#characterLeft').removeClass('red');            
					}
			});    


					
			$("#name").keydown(function()
			{
					var name = $("#name").val();   
						if(name.length<=0)
						{
						    $("#username").html("You can't leave this empty.");
							
							
						}
						else
						{
							$("#username").html("");
							
						}
			});
			$("#email").keydown(function()
			{
						
							var num = new RegExp("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/");
							var email = $("#email").val(); 
							
							if($("#email").val().length<=0){
								$("#email_error").html("You can't leave this empty.");
								
							}
							else if(!isValid(email)){
								$("#email_error").html("Email is not valid");
								
							}else{
								$("#email_error").html("");
								
							}
							function isValid(email) 
							{
								var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
								//alert( pattern.test(emailAddress) );
								return pattern.test(email);
							};
					
			});
			$("#mobile").keydown(function()
			{
				var mobile = $("#mobile").val();
                var num = new RegExp("[0-9]+");				
						if(mobile.length<=0)
						{
						    $("#mobile_error").html("You can't leave this empty.");
							
						}
						else if(!num.test(mobile))
						{
						  	$("#mobile_error").html("Mobile number is not valid");
							
						}
						else
						{
							$("#mobile_error").html("");
							
						}
			});
			
			$("#room_no").keydown(function()
			{
				var room = $("#room_no").val();
                var num = new RegExp("[0-9]+");				
						if(room.length<=0)
						{
						    $("#room_error").html("You can't leave this empty.");
							
						}
						else if(!num.test(room))
						{
						  	$("#room_error").html("Room number is not valid");
							
						}
						else
						{
							$("#room_error").html("");
							
						}
			});	
			$("#comp_regard").keydown(function()
			{
				var comp = $("#comp_regard").val();
                				
						if(comp.length<=0)
						{
						    $("#complaint_regard").html("You can't leave this empty.");
							
						}
						else
						{
							$("#complaint_regard").html("");
							
						}
			});
			$("#message").keydown(function()
			{
				var msg = $("#message").val();
                				
						if(msg.length<=0)
						{
						    $("#complaint").html("You can't leave this empty.");
							
						}
						else
						{
							$("#complaint").html("");
							
						}
			});
				$(document).ready(function ()
				{   
					
						$("#comp_form").on('submit',(function(e){
						e.preventDefault();
						var name = $("#name").val();
						var email = $("#email").val();
						var mobile = $("#mobile").val();
						var room = $("#room_no").val();
						var comp = $("#comp_regard").val();
						var msg = $("#message").val();
						
						
						if(name.length>0&&email.length>0&&mobile.length>0&&room.length>0&&comp.length>0&&msg.length>0){	
								
								$.ajax({
										url: "complaint_submit.php",
										type: "POST",
										data:  new FormData(this),
										contentType: false,
										cache: false,
										processData:false,	
										success: function(data){
											document.getElementById("comp_form").reset();
											if(data){
											alert(data);
											}
										} 	        
								});
							
						}else{
							$("#username").html("You can't leave this empty.");
							$("#email_error").html("You can't leave this empty.");
							$("#mobile_error").html("You can't leave this empty.");
							$("#room_error").html("You can't leave this empty.");
							$("#complaint_regard").html("You can't leave this empty.");
							 $("#complaint").html("You can't leave this empty.");
							 return false;
						}
						}));
				});	
						
	});
	$(document).ready(function ()
    { 
			$("input[type=password]").keyup(function(){
			var ucase = new RegExp("[A-Z]+");
			var lcase = new RegExp("[a-z]+");
			var num = new RegExp("[0-9]+");
			
			if($("#password1").val().length >= 8){
				$("#8char").removeClass("glyphicon-remove");
				$("#8char").addClass("glyphicon-ok");
				$("#8char").css("color","#00A41E");
			}else{
				$("#8char").removeClass("glyphicon-ok");
				$("#8char").addClass("glyphicon-remove");
				$("#8char").css("color","#FF0004");
			}
			
			if(ucase.test($("#password1").val())){
				$("#ucase").removeClass("glyphicon-remove");
				$("#ucase").addClass("glyphicon-ok");
				$("#ucase").css("color","#00A41E");
			}else{
				$("#ucase").removeClass("glyphicon-ok");
				$("#ucase").addClass("glyphicon-remove");
				$("#ucase").css("color","#FF0004");
			}
			
			if(lcase.test($("#password1").val())){
				$("#lcase").removeClass("glyphicon-remove");
				$("#lcase").addClass("glyphicon-ok");
				$("#lcase").css("color","#00A41E");
			}else{
				$("#lcase").removeClass("glyphicon-ok");
				$("#lcase").addClass("glyphicon-remove");
				$("#lcase").css("color","#FF0004");
			}
			
			if(num.test($("#password1").val())){
				$("#num").removeClass("glyphicon-remove");
				$("#num").addClass("glyphicon-ok");
				$("#num").css("color","#00A41E");
			}else{
				$("#num").removeClass("glyphicon-ok");
				$("#num").addClass("glyphicon-remove");
				$("#num").css("color","#FF0004");
			}
			
			if($("#password1").val() == $("#password2").val()){
				$("#pwmatch").removeClass("glyphicon-remove");
				$("#pwmatch").addClass("glyphicon-ok");
				$("#pwmatch").css("color","#00A41E");
			}else{
				$("#pwmatch").removeClass("glyphicon-ok");
				$("#pwmatch").addClass("glyphicon-remove");
				$("#pwmatch").css("color","#FF0004");
			}
		});
	
	});
			$(document).ready(function()
    {
		$('#loginform').on('submit',(function(e){
						e.preventDefault();
						
						var usrname = $("#username").val();
						var paswd   = $("#ad_password").val();
					
						
						if(usrname.length>0&&paswd.length>0)
						{	
								
								$.ajax({
										url: "admin_login.php",
										type: "POST",
										data:  new FormData(this),
										contentType: false,
										cache: false,
										processData:false,	
										success: function(data){
											
											if(!$.trim(data)){
										    location.reload();
											
											}else{
												
											$("#error_msg").html(data);
											$("#error_msg").addClass("error_msg2");
											$("#user_error").html("");
							                $("#pswd_error").html("");
											}
										} 	        
								});
							
						}else{
							$("#user_error").html("You can't leave this empty.");
							$("#pswd_error").html("You can't leave this empty.");
							
							
							 return false;
						}
						}));
	});
	
$(document).ready(function()
    {
		$('#loginform').on('submit',(function(e){
						e.preventDefault();
						
						var usrname = $("#username").val();
						var paswd   = $("#ad_password").val();
					
						
						if(usrname.length>0&&paswd.length>0)
						{	
								
								$.ajax({
										url: "admin_login.php",
										type: "POST",
										data:  new FormData(this),
										contentType: false,
										cache: false,
										processData:false,	
										success: function(data){
											
											if(!$.trim(data)){
										    location.reload();
											
											}else{
												
											$("#error_msg").html(data);
											$("#error_msg").addClass("error_msg2");
											$("#user_error").html("");
							                $("#pswd_error").html("");
											}
										} 	        
								});
							
						}else{
							$("#user_error").html("You can't leave this empty.");
							$("#pswd_error").html("You can't leave this empty.");
							
							
							 return false;
						}
						}));
	});

$(document).ready(function()
    {
		$('#loginform2').on('submit',(function(e){
						e.preventDefault();
						
						var usrname = $("#username").val();
						var paswd   = $("#ad_password").val();
					
						
						if(usrname.length>0&&paswd.length>0)
						{	
								
								$.ajax({
										url: "admin_login.php",
										type: "POST",
										data:  new FormData(this),
										contentType: false,
										cache: false,
										processData:false,	
										success: function(data){
											
											if(!$.trim(data)){
										    location.reload();
											
											}else{
												
											$("#error_msg").html(data);
											$("#error_msg").addClass("error_msg2");
											$("#user_error").html("");
							                $("#pswd_error").html("");
											}
										} 	        
								});
							
						}else{
							$("#user_error").html("You can't leave this empty.");
							$("#pswd_error").html("You can't leave this empty.");
							
							
							 return false;
						}
						}));
	});	
		
