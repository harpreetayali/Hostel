	   
	<?php include("header.php");?>			
		<div class="row" style="margin-top: 68px;">
		<div class="col-md-2 col-sm-2">
		</div>
		<div class="about col-md-8 col-sm-8">
		<h2 class="heading"><strong>About Us </strong>  <span></span></h2>
		
		<p>GNDP is a completely residental campus with three story hostel for sudents accomodating. There is a hostel (No. III) for polytechnic students. It has 8 cubicales, 04 Single seater,48 Three Seaters and 13 four seaters dormitories. The hostel has been provided with modern amenities i.e. Wi-Fi, indoor games, clubs, good water supply, geyser ,Washing Machine,Mess Facility,comfortable dinning hall,newspaper,magazines,Guest rooms,Special rooms and T.V. including cable T.V. Facilities are also available in all the hostels. Hostel is also provided with the telephone The separate hostel is also available for girls and also have the same amenities</p>
		<table border=1 class="contact-table" >
        <thead>
		<tr >
		<th class="td" > Sr. No.  </th>
		<th class="td"> Name </th>
		<th class="td"> Contact no.</th>  
		
		</tr>
		<tr>
		<td class="td"> 1</td>
		<td class="td"> Er. Hardeep Singh Jawanda</td>
		<td class="td">98729-55518</td>
		</tr>
		<tr>
		<td class="td">
        2
        </td>
		<td class="td">Er. Joga Singh </td>
		<td class="td">98554-90633</td>
		</tr>
        <tr>
		<td class="td">
        3
        </td>
		<td class="td">Er. Gagandeep Kaur </td>
		<td class="td">99145-02244</td>
		</tr>

		</table>
		</div>
		
		<div class="col-md-2 col-sm-2">
		</div>
		</div>
		 <?php include("footer.php");?>		
          