 <?php




$con = mysqli_connect("localhost","root","","hostel");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();
?> 








    <title>Hostel</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="icon" type="image/png" href="img/logo2.png">
		
		<link rel="stylesheet" href="css/custom.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
        
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/insert.js"></script>  
		
		    
		  
	    <body id="myPage">
	
	<?php
	 if(isset($_SESSION['user_id'])){
	echo '
	<nav class="navbar navbar-default navbar-fixed-top" style=" background-color: rgb(128, 0, 0);">
	
	
	
	    <div class="container">
			<div class="navbar-header">
				<a href="#myPage"><img class="head-logo" src="img/logo2.png" /></a>
				  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>                        
				  </button>
				
			</div>
				<div class="collapse navbar-collapse" id="myNavbar ">
				    <ul class="nav navbar-nav  nav-color">
					        <li ><a href="index.php" >Home</a></li>
							<li  class="dropdown">
						<a href="" class="dropdown-toggle" data-toggle="dropdown">Rooms <span class="caret"></span></a>				
						<ul class="dropdown-menu" role="menu">
							<li><a role="menuitem" href="ground.php">Ground</a></li>
							<li><a role="menuitem" href="1st_floor.php">Floor 1</a></li>
							<li><a role="menuitem" href="2nd_floor.php">Floor 2</a></li>
						</ul>
							</li>
						  <li ><a href="services.php">Services</a></li>
						  
						  <li ><a href="gallery.php">Gallery</a></li>
						   <li ><img src="img/logo2.png" class="logo"></li>
						  <li ><a href="registration.php">Registration</a></li>
						  <li ><a href="aboutus.php">About US</a></li>
						  <li  class="dropdown">
						<a href="" class="dropdown-toggle" data-toggle="dropdown">Admin <span class="caret"></span></a>				
						<ul class="dropdown-menu" role="menu">
							<li id="admin_panel"><a href="admin/" target="_blank">Admin Panel</a></li>
							<li id="logout"><a href="logout.php">Logout</a></li>
						</ul>
							</li>
						
						
				    </ul>
				</div>
	    </div>
	</nav>';
	 }else{
	
	
	
	echo '<nav class="navbar navbar-default navbar-fixed-top" style=" background-color: rgb(128, 0, 0);">
	
	
	
	    <div class="container">
			<div class="navbar-header">
				<a href="#myPage"><img class="head-logo" src="img/logo2.png" /></a>
				  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>                        
				  </button>
				
			</div>
				<div class="collapse navbar-collapse" id="myNavbar ">
				    <ul class="menu nav navbar-nav  nav-color">
					        <li ><a href="index.php" >Home</a></li>
							<li  class="dropdown">
						<a href="" class="dropdown-toggle" data-toggle="dropdown">Rooms <span class="caret"></span></a>				
						<ul class="dropdown-menu" role="menu">
							<li><a role="menuitem" href="ground.php">Ground</a></li>
							<li><a role="menuitem" href="1st_floor.php">Floor 1</a></li>
							<li><a role="menuitem" href="2nd_floor.php">Floor 2</a></li>
						</ul>
							</li>
						  <li ><a href="services.php">Services</a></li>
						  <li ><a href="gallery.php">Gallery</a></li>
						  <li ><img src="img/logo2.png" class="logo"></li>
						  <li ><a href="registration.php">Registration</a></li>
						  <li ><a href="aboutus.php">About US</a></li>
						  <li ><a href="#" data-toggle="modal" data-target="#login_modal">Log In</a></li>
						
				    </ul>
				</div>
	    </div>
	</nav>';
	
	
	
	
	
	
	
	}?> 
		<div class="modal modal-wide fade" id="login_modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
									<h5 class="modal-title">Login</h5>
								</div>
                            <form  id="loginform" method="post" class="form-horizontal">
								<div class="modal-body">
									
									
										<div class="form-group">
										<div id="error_msg" class=""></div>
											<label class="col-xs-3 control-label">Username</label>
											<div class="col-xs-5">
											
										<input placeholder="Username" id="username" type="text" class="form-control" name="user_name" />
											<span id="user_error" ></span>	
											</div>
										</div>

										<div class="form-group">
											<label class="col-xs-3 control-label">Password</label>
											<div class="col-xs-5">
											<input placeholder="Password" id="ad_password" type="password" class="form-control" name="password" />
											<span id="pswd_error"></span>
											</div>
										</div>

										<div class="form-group">
											<div class="col-xs-5 col-xs-offset-3">
												<button  id="login" type="submit" class="login_button">Login</button>
												<button type="button" class="login_button2" data-dismiss="modal">Cancel</button>
											</div>
										</div>
									</div>
									
								</form>
							</div>
						</div>
				</div>
	
	