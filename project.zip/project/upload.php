 <?php




$con = mysqli_connect("localhost","root","","hostel");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();
?> 
<?php

if(is_array($_FILES)) {
    $name = $_FILES["filetoupload"]["name"];
	$tmp_name = $_FILES['filetoupload']['tmp_name'];
	
								$target_dir = "uploads/";
							
								$target_file = $target_dir .basename($name);
								
								
								$uploadOk = 1;
								$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
								// Check if image file is a actual image or fake image
								if(isset($_POST["submit"])) {
									$check = getimagesize($tmp_name);
									if($check !== false) {
										echo "File is an image - " . $check["mime"] . ".";
										$uploadOk = 1;
									} else {
										echo "File is not an image.";
										$uploadOk = 0;
									}
								}
								if (file_exists($target_file)) {
									echo "Sorry, file already exists."."<br>";
									$uploadOk = 0;
								}
																
								if ($_FILES["filetoupload"]["size"] > 500000) {
									echo "Sorry, your file is too large."."<br>";
									$uploadOk = 0;
								}
								
								if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
									&& $imageFileType != "gif" ) {
										echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed."."<br>";
										$uploadOk = 0;
									}
								if ($uploadOk == 0) {
									echo "Sorry, your file was not uploaded.";
								
								}else {
									
									if(move_uploaded_file($tmp_name,$target_file)){
									    
									 $row = mysqli_query($con,"select reg_id from registration ORDER BY reg_id DESC");
		                            $reg_no = mysqli_fetch_array($row);
									$reg_id = $reg_no['reg_id'];
									$path = "uploads/".$_FILES['filetoupload']['name']; 
									$query = "UPDATE `registration` SET image ='$path' WHERE `registration`.`reg_id` = '$reg_id'";
	                                mysqli_query($con,$query );
									echo "Uploaded";
										
									}
									else{
										echo "Sorry,there was an error";
									}
								}
                            } 
								?>		
