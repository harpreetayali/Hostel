  
  
   <?php




$con = mysqli_connect("localhost","root","","hostel");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();
 

                    $message="";
					if(count($_POST)>0) {
					$result = mysqli_query($con,"SELECT * FROM admin WHERE username='" . $_POST["user_name"] . "' and password = '". $_POST["password"]."'");

					$count=mysqli_num_rows($result);
					$row  = mysqli_fetch_array($result);

					if($count==1) {
					$_SESSION["user_id"] = $row['uid'];
					$_SESSION["user_name"] = $row['username'];
					}
					else{
						echo "Wrong username and password";
					}
					}
					
					
					
					
					?>