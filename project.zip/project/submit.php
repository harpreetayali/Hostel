 <?php include('header.php');
 	
 ?> 


<?php
if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$course = $_POST['block'];
	$block = $_POST['block'];
	$rollno = $_POST['roll_no'];
	$class = $_POST['class'];
	$father_name = $_POST['f_name'];
	$father_occupation = $_POST['f_occupation'];
	$student_email = $_POST['s_email'];
	$parent_email = $_POST['p_email'];
	$student_mobile_no = $_POST['s_m_no'];
	$father_landline_no = $_POST['f_l_no'];
	$father_mobile_no = $_POST['f_m_no'];
	$blood_group = $_POST['blood_group'];
	$fee_reciept_no = $_POST['receipt_no'];
	$amount = $_POST['amount'];
	
	$attached_rooms = $_POST['attached_rooms'];
	if(isset($_POST['attached_rooms']))
		$attached_rooms  = 	$_POST['attached_rooms'];
    if($attached_rooms == 'yes'){
		$block = 'all';
		}
		else if($attached_rooms == 'single'){
		$block = 'staff';
		echo $block;
		}
	
	$result = mysqli_query($con,"select * from hostel_rooms where block='".$block."'");
	
	$success = true;
	$room_id = '';	
	
	$results = mysqli_fetch_all($result, MYSQLI_ASSOC);
	
	foreach($results as $list){
		$success = false;
		$row = mysqli_query($con,"select COUNT(reg_id) as total from registration where room='".$list['room_no']."'");
		
		$reg_info = mysqli_fetch_row($row);
        
		if((isset($reg_info[0]) and $reg_info[0] < 3)){
			$room_no = $list['room_no'];
			$success = true;	
			break;
		
		}		
		
	}
	
	$query = "INSERT INTO `registration` ( `room`, `student_name`, `course`,`roll_no`,`class`,`father_name`,`father_occupation`,`student_email`,`parent_email`,`student_mobile`,`father_landline_no`,`father_mobile`,`blood_group`,`fee_receipt_no`,`amount`,`available`) VALUES ('$room_no	', '$name', '$course', '$rollno','$class','$father_name','$father_occupation', '$student_email', '$parent_email', '$student_mobile_no','$father_landline_no','$father_mobile_no','$blood_group','$fee_reciept_no','$amount','Yes');";
    
	if($success == true){	
		$submit = mysqli_query($con,$query);
		mysqli_query($con,"UPDATE `furniture` SET `beds` = `beds`-1, `tables` = `tables`-1, `chairs` = `chairs`-1 WHERE `furniture`.`furniture_id` = 1;");
		
		
	}else{
		$error_rooms = 'Sorry room is not available';
		
	}
}

	
?>		
    <?php
     if(!isset($error_rooms))
	{
	 ?>

            
			
	            <table border="1" class="table2 ">

								<thead>
    					<tr>
									
									<th colspan="3" style="text-align: center; padding-bottom: 22px;">Form Detail</th>
																		
							<tr>
								</thead>
								<tbody>
								
								<tr>
									<td><label>Profile Image</label></td>
									
									<td><form id="form1" action="upload.php" method="post" enctype="multipart/form-data">	
					
					<label>Select image <br>to upload:</label>
					<input  type="file" name="filetoupload" id="filetoupload" >
						<input type="submit" value="Upload Image"  name="file_upload" id="file_upload">
					  
					  <div id="error2"></div>
				</form></td>
									
								
									</tr>
									<tr>
									<td><label>Name</label></td>
									<td><?=$name?></td>
									
								
									</tr>
									
								<tr>
									<td><label>Course</label></td>
									<td><?=$course?></td>
									
								
								</tr>
									
								<tr>
									<td><label>Roll No</label></td>
									<td><?=$rollno?></td>
									
								
								</tr>
									
								<tr>
									<td><label>Class</label></td>
									<td><?=$class?></td>
									
								
								</tr>
									
								<tr>
									<td><label>Father Name</label></td>
									<td><?=$father_name?></td>
									
								
								</tr>
								<tr>
									<td><label>Father Occupation</label></td>
									<td><?=$father_occupation?></td>
									
								
								</tr>
									
								<tr>
									<td><label>Student Email</label></td>
									<td><?=$student_email?></td>
									
								
								</tr>
									
								<tr>
									<td><label>Parent Email</label></td>
									<td><?=$parent_email?></td>
									
								
								</tr>
									<tr>
									<td><label>Student Mobile No</label></td>
									<td><?=$student_mobile_no?></td>
								</tr>
									
							</tr>
								<tr>
									<td><label>Father Landline No</label></td>
									<td><?=$father_landline_no?></td>
									
								
								</tr>
									
						</tr>
								<tr>
									<td><label>Father Mobile No</label></td>
									<td><?=$father_mobile_no?></td>
									
								
								</tr>
								
								<tr>
									<td><label>Blood Group</label></td>
									<td><?=$blood_group?></td>
									
								
								</tr>
									
						        <tr>
									<td><label>Fee Reciept No</label></td>
									<td><?=$fee_reciept_no?></td>
									
								
								</tr>
									
								<tr>
									<td><label>Amount</label></td>
									<td><?=$amount?></td>
								</tr>
									
								<tr>
									<td><label>Room Allotted</label></td>
									<td><?=$room_no?></td>
								</tr>
								
								</tbody>
								
								
								
				</table>
			<table border="1" class="table3">
				<thead>
					<tr>
					  
					  <th colspan="3" style="text-align:center;">Furniture Alloted </th>
					 </tr> 
				
				</thead>
								
				<tbody>
					<tr>
					    <td>Bed</td>
						<td>Chair</td>
						<td>Table</td>
											
					
					</tr>
					<tr>
					    <td>1</td>
						<td>1</td>					
					    <td>1</td>
					</tr>
					
				<tbody>
			</table>
		<form>
		 <input type="button" value="Print" onclick="printpage();" class="print_btn">
		</form>
	<?php
		
	}else
	{
		
	?>
         <div class="alert-danger error-form"><?=$error_rooms?></div>
							
							
                    								

	<?php 
	}?>
							   
                    <script>							
							function printpage()
							  {
							   window.print();
							  }
							window.onload= alert('Must upload your profile');  
					</script>

					
<?php include('footer.php');?>
