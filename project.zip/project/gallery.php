<?php include("header.php");?>	

		<div class="container " style="margin-top: 69px;">
						<h2 class="heading"><strong>Gallery </strong>  <span></span></h2>
            <div class="row">	
                <div class="col-sm-12  col-md-4 img img1">
				   <a class="zoom" href="img/hostel_entry.jpg">
						  <img src="img/hostel_entry.jpg" class="img-thumbnail">
				   </a>
				        <h3 class="text-center text-color">Hostel Entry Gate</h3>
			   </div>
				<div class="col-sm-12 col-md-4 img img1">
				<a class="zoom" href="img/entry.jpg">
				      <img src="img/entry.jpg" class="img-thumbnail">
				</a>
				<h3 class="text-center text-color">Hostel Entrance</h3>
				</div>
				
               
			   <div class="col-sm-12 col-md-4 img img1">
			   <a class="zoom" href="img/club1.jpg">
			           <img src="img/club1.jpg" class="img-thumbnail"> 
               </a>
			   <h3 class="text-center text-color">Club Entertainment</h3>
			   </div>
               <div class="col-sm-12 col-md-4 img img1">
			   <a class="zoom" href="img/club.jpg">
                       <img src="img/club.jpg" class="img-thumbnail">
               </a>
			   <h3 class="text-center text-color">Club Games</h3>
			   </div> 
			    <div class="col-sm-12 col-md-4 img img1">
				<a class="zoom" href="img/mess1.jpg">
                      <img src="img/mess1.jpg" class="img-thumbnail">
                </a>
				<h3 class="text-center text-color">Mess Entrance</h3>
				</div>
			   <div class="col-sm-12 col-md-4 img img1" >
			   <a class="zoom" href="img/mess2.jpg">
			           <img src="img/mess2.jpg" class="img-thumbnail img-width">
			   </a>
			   <h3 class="text-center text-color">Mess</h3>
			   </div>
			  
               

  			</div>
			
		</div>
		
                			
      <?php include("footer.php");?>	  