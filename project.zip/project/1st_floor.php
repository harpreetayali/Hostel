<?php include("header.php");

?>
 
	
	<h2 class="text-color floor-heading">First Floor</h2>
	
	<img class="floor-image img-responsive" src="img/1stfloor.jpg" usemap="#1floormap">
						
	<map name="1floormap">
							<?php
							$result = mysqli_query($con ,"select * from hostel_rooms where floor_type='1' ");  
						
		while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))   
        { 
							
																
									echo '<area alt="'.$row['room_no'].'" title="" href="#normalModal_'.$row['room_id'].'" data-toggle="modal" shape="rect" coords="'.$row['x_axis'].','.$row['y_axis'].','.$row['z_axis'].','.$row['a_axis'].'" />';
									
							
					$count = mysqli_query($con,"select COUNT(reg_id) as total from registration where room=".$row['room_no']);
					$total_no_students = mysqli_fetch_row($count);
					$info = mysqli_query($con, "select * from registration where room='".$row['room_no']."' AND available='Yes'" );  	
								
							?>	
            
					
                <?php
				if(isset($_SESSION["user_id"])) {?>
				
					<div id="normalModal_<?=$row['room_id']?>" class="modal modal-wide fade">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									
									<h4 class="modal-title">Room Detail</h4>
								
								</div>
							  <div class="modal-body">
								<p class="popup">Room no. = <?=$row['room_no']?> Total student = <?=$total_no_students[0]?></p>
							<table border="1" class="table table-striped custab">

								<thead>
    							<tr>
									<th>Sr.No.</th>
									<th>Student Name</th>
									<th>Roll no.</th>
								<tr>
								</thead>
								<tbody>
								<?php
								$i = 0;
								while ($room_detail = mysqli_fetch_array($info, MYSQLI_ASSOC))   
								{ 
								$i++;
								?>
									<tr>
									<td><?=$i?></td>
									<td><?=$room_detail['student_name']?></td>
									<td><?=$room_detail['roll_no']?></td>
									
									
									
									</tr>
								<?php } ?>	
								</tbody>
								
								
								
							</table>
								
								
								
								
							  </div>
							  <div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								
							  </div>
							</div>
						 </div>
					</div>
				<?php
				}else{
					
				?>
				<div class="modal modal-wide fade" id="normalModal_<?=$row['room_id']?>" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
									<h5 class="modal-title">Login</h5>
								</div>
                            <form  id="loginform" method="post" class="form-horizontal">
								<div class="modal-body">
									
									
										<div class="form-group">
										<div id="error_msg" class=""></div>
											<label class="col-xs-3 control-label">Username</label>
											<div class="col-xs-5">
											
										<input placeholder="Username" id="username" type="text" class="form-control" name="user_name" />
											<span id="user_error" ></span>	
											</div>
										</div>

										<div class="form-group">
											<label class="col-xs-3 control-label">Password</label>
											<div class="col-xs-5">
											<input placeholder="Password" id="ad_password" type="password" class="form-control" name="password" />
											<span id="pswd_error"></span>
											</div>
										</div>

										<div class="form-group">
											<div class="col-xs-5 col-xs-offset-3">
												<button  id="login" type="submit" class="login_button">Login</button>
												<button type="button" class="login_button2" data-dismiss="modal">Cancel</button>
											</div>
										</div>
									</div>
									
								</form>
							</div>
						</div>
				</div>
			
					
			
			
			
			
			
				<?php	
				}					
				  
				?>

			
		<?php	
		}
		?>
							
		</map>

				
			
			
			 <?php include("footer.php");?>	
			