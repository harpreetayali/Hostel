	<?php include("header.php");?>			
        
					
					<h2 class="heading" style="margin: 82px 7px 0px 22px;"><strong>Services </strong>  <span></span></h2>
					    <div class="row" style="margin: 25px 7px 0px 22px;">
								<div class="col-sm-12 col-md-4">
									  <img class="img-responsive"src="img/mess2.jpg" height="265" width="100%" />
									  <br><br><br><br>
									   <img class="img-responsive" src="img/club.jpg" style="margin-bottom: 30px;" width="100%" height="265">
								</div>
									  <div class="col-sm-12 col-md-4">
										  <h2 class="text-color">Mess</h2>
										  <p class="font-style">We provide good quality food to our students. There is good sitting arrangement for the students. We care for the health of students so we provide the healthy food. There is a weekly menu for the students made by them. we provide three time food  and one time tea. </p>
									     
									      <h2 class="text-color" style="margin-top: 192px;">Club</h2>
										  <p class="font-style">We also care for the entertainment of the students. So we provide them club facility to watch T.V. and play indoor games. There is good sitting arrangement in the club so students can watch the T.V. We provide some indoor games like table tennis,chess,darts and carrom board. </p>
										<br><br><br>
		                    </div>
				<div class="col-sm-12 col-md-4">
										
									
					<div class="form-area">  
											 
						 <form role="form" id="comp_form" method="post" action="complaint_submit.php">
											 <br style="clear:both">
											<h3 class="text-color" style="margin-bottom: 25px; text-align: center;">Complaint Form</h3>
											<div class="form-group">
												<input type="text" class="form-control " class="required" id="name" name="name" placeholder="Name" >
												<span id="username" class="form_error"></span>
											</div>
											
											<div class="form-group">
												<input type="text" class="form-control" id="email" name="email" placeholder="Email" >
												<span id="email_error" class="form_error"></span>
											</div>
											
											<div class="form-group">
												<input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile Number" >
												
												<span id="mobile_error" class="form_error"></span>
											</div>
											
											<div class="form-group">
												<input type="text" class="form-control" id="room_no" name="room_no" placeholder="Room no." maxlength="3" >
												
												<span id="room_error" class="form_error"></span>
											</div>
											
											<div class="form-group">
											<select class="form-control" id="comp_regard" name="comp_regard">
																<option value="" >Complaint Regarding</option>
																<option value="room" >Room</option>
																<option value="mess_food" >Mess food</option>
																<option value="other" >Other </option>
																</select>
																<span id="complaint_regard" class="form_error"></span>
											</div>
											
											<div class="form-group">
											<textarea class="form-control" type="textarea" name="message" id="message" placeholder="Complaint" maxlength="140" rows="7"></textarea>
												 
                                            <span id="complaint" class="form_error"></span>												
											</div>
									
					<button type="submit" id="submit_complaint" name="submit_complaint" class="comp_form">Submit Form</button>
								</form>
							</div>
						
						
                </div>							
					    </div>
					
				
		
        
						
						
                   
												
									 
							    
					
            	
		
				 <?php include("footer.php");?>	