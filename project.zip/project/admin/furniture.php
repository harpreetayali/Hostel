<?php include("header_admin.php");



?>

<?php if(isset($_SESSION['user_id']))
		{   ?>
				<div class="wrapper">
				 <div class="sidebar" data-color="brown" data-image="img/hostel_entry_sidebar.jpg">

					
						<div class="sidebar-wrapper">
							<div class="logo">
								<a href="" class="simple-text">
									Admin Panel
								</a>
							</div>

							<ul class="nav">
								<li >
									<a href="index.php">
										<i class="pe-7s-graph"></i>
										<p>Dashboard</p>
									</a>
								</li>
								<li >
									<a href="update_data.php">
										<i class="pe-7s-user"></i>
										<p>Update Data</p>
									</a>
								</li>
								<li>
									<a href="complaints.php">
										<i class="pe-7s-note2"></i>
										<p>Complaints</p>
									</a>
								</li>
								<li class="active">
									<a href="furniture.php">
										<i class="pe-7s-note2"></i>
										<p>Furniture</p>
									</a>
								</li>
								<li>
									<a href="change_password.php">
										<i class="pe-7s-news-paper"></i>
										<p>Change Password</p>
									</a>
								</li>
								
								
							</ul>
						</div>
					</div>
					<div class="main-panel">
						<nav class="navbar navbar-default navbar-fixed">
							<div class="container-fluid">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
									<a class="navbar-brand" href="#">Dashboard</a>
								</div>
								<div class="collapse navbar-collapse">
									<ul class="nav navbar-nav navbar-left">
										<li>
											<a href="#" class="dropdown-toggle" data-toggle="dropdown">
												
												<p class="hidden-lg hidden-md">Dashboard</p>
											</a>
										</li>
										
									   
									</ul>

									<ul class="nav navbar-nav navbar-right">
									   
										
										<li>
											<a href="logout.php">
												<p>Log out</p>
											</a>
										</li>
										
									</ul>
								</div>
							</div>
						</nav>


						<div class="content">
						    
								<div class="row">
									
										<div class="card">
										<div class="header">
													<h4 class="title">Furniture Available</h4>
												</div>
											<div class="content ">
												<table class="table table-hover table-striped">
													<thead>
														<th>ID</th>
														<th>Beds</th>
														<th>Tables</th>
														<th>Chairs</th>
														
													</thead>
													<tbody>
													<?php
													$info = mysqli_query($con,"SELECT * FROM `furniture`");
													$furniture_detail = mysqli_fetch_array($info, MYSQLI_ASSOC);  
													
													
													?>
														<tr>
															<td><?=1?></td>
															<td><?=$furniture_detail['beds']?></td>
															<td><?=$furniture_detail['tables']?></td>
															<td><?=$furniture_detail['chairs']?></td>
														
														</tr>
													   
													</tbody>
												</table>	

											</div>
										
										</div>
									<button type="button" class="fur_update" id="update_furniture" data-toggle="modal" data-target="#myModal">Update</button>		
								</div>
															
						</div>

                     
						

					</div>
				</div>
			<div id="myModal" class="modal modal-wide fade">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									
									<h4 class="modal-title">Update Furniture</h4>
								
								</div>
							  <div class="modal-body">
								<p class="popup"></p>
							<form  id="furn_form" method="post" class="form-horizontal">
								<div class="modal-body">
									
									
										<div class="form-group">
										
											<label class="col-xs-3 control-label">Beds</label>
											<div class="col-xs-5">
												
												<input  maxlength="3" id="beds" type="text" class="form-control" name="beds" />
												<span style="color:red;" id="beds_error"></span>
													
											    
											</div>
										</div>

										<div class="form-group">
											<label class="col-xs-3 control-label">Tables</label>
											<div class="col-xs-5">
											
   											    <input  maxlength="3" id="tables" type="text" class="form-control" name="tables" />
											    <span style="color:red;" id="tables_error"></span>
											
											</div>
										</div>
										<div class="form-group">
											<label class="col-xs-3 control-label">Chairs</label>
											<div class="col-xs-5">
												
												<input  maxlength="3" id="chairs" type="text" class="form-control" name="chairs" />
											    <span style="color:red;" id="chairs_error"></span>
											
											</div>
										</div>

										<div class="form-group">
											<div class="col-xs-5 col-xs-offset-3">
												
												<button  id="update" type="submit" class="update_button">Update</button>
												
											</div>
										</div>
									</div>
									
								</form>
								
								
								
								
							  </div>
							  <div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								
							  </div>
							</div>
						 </div>
					</div>

		<?php
		}
		?>