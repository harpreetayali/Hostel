 <?php




$con = mysqli_connect("localhost","root","","hostel");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();

?> 
<?php
$new_pswd = $_POST['password2'];

$result = mysqli_query($con,"UPDATE `admin` SET `password` = '".$new_pswd."' WHERE `admin`.`uid` = 1;");

if($result==true){
	
	echo "Password changed successfully";
	
	
}else{
	
	echo "Password does not changed successfully";
}

session_destroy();

?>

