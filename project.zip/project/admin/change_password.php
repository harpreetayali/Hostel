<?php include("header_admin.php");?>
	
	<?php if(isset($_SESSION['user_id']))
		{   ?>
			 <div class="wrapper">
				<div class="sidebar" data-color="brown" data-image="img/mess_sidebar4.jpg">

				

					<div class="sidebar-wrapper">
						<div class="logo">
							<a href="" class="simple-text">
								Admin Panel
							</a>
						</div>

						<ul class="nav">
							<li>
								<a href="index.php">
									<i class="pe-7s-graph"></i>
									<p>Dashboard</p>
								</a>
							</li>
							<li >
								<a href="update_data.php">
									<i class="pe-7s-user"></i>
									<p>Update Data</p>
								</a>
							</li>
							<li>
								<a href="complaints.php">
									<i class="pe-7s-note2"></i>
									<p>Complaints</p>
								</a>
							</li>
							<li>
									<a href="furniture.php">
										<i class="pe-7s-note2"></i>
										<p>Furniture</p>
									</a>
							</li>
							<li class="active">
								<a href="change_password.php">
									<i class="pe-7s-news-paper"></i>
									<p>Change Password</p>
								</a>
							</li>
							
							
						</ul>
					</div>
				</div>

				<div class="main-panel">
					<nav class="navbar navbar-default navbar-fixed">
						<div class="container-fluid">
							<div class="navbar-header">
								<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
								<a class="navbar-brand" href="#">Change Password</a>
							</div>
							<div class="collapse navbar-collapse">
							   

								<ul class="nav navbar-nav navbar-right">
									
									<li>
										<a href="logout.php">
											<p>Log out</p>
										</a>
									</li>
									
								</ul>
							</div>
						</div>
					</nav>


					<div class="content">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div class="card">
										
										<div class="content">
							<div class="row" style="text-align: center;">
								<div class="col-sm-4 ">
								</div>
								<div class="col-sm-4 ">
								
							<form action="admin_password_submit.php" method="post" id="passwordForm">
									
                                  <input type="password" class="form-control " name="old_pass" id="old_pass" placeholder="Old Password" >
							<div class="row valid_text">
                            
							 <span id="oldpswd_error" style="color:red;"></span>
								
							</div>
									<input type="password" class="form-control" name="password1" id="password1" placeholder="New Password" >

							<div class="row valid_text">
                            
							 <span id="newpswd_error" style="color:red;"></span>
								
							</div>
								
								<input type="password" class="form-control" name="password2" id="password2" placeholder="Confirm Password" >
							<div class="row">
								
								<div class="col-sm-12 valid_text">
									<span id="pwmatch" class="glyphicon glyphicon-remove" style="color:#FF0004;"></span> Passwords Match
								</div>
								
							</div>
									<input type="submit" class="btn_pswd"  id="admin_password" value="Change Password">
												</form>
								</div><!--/col-sm-6-->
								<div class="col-sm-4">
								</div>
										</div><!--/row-->
				
										
						

					

										</div>
									</div>
								</div>

							</div>
						</div>
					</div>

					

				</div>
			</div>

		<?php 
		}  
		?>
