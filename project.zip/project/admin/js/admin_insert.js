
$(document).ready(function (l){
$("#form1").on('submit',(function(l){
l.preventDefault();
$.ajax({
url: "upload.php",
type: "POST",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,	
success: function(data){
	$("#error2").html(data);
	if(!data){
	$("#file_upload").hide(this);
	}
},
error: function(){} 	        
});
}));
});
$(document).ready(function ()
    { 
		$('#characterLeft').text('140 characters left');
			$('#message').keydown(function () 
			{
					var max = 140;
					var len = $(this).val().length;
					if (len >= max) 
					{
						$('#characterLeft').text('You have reached the limit');
						$('#characterLeft').addClass('red');
						$('#btnSubmit').addClass('disabled');            
					} 
					else 
					{
						var ch = max - len;
						$('#characterLeft').text(ch + ' characters left');
						$('#btnSubmit').removeClass('disabled');
						$('#characterLeft').removeClass('red');            
					}
			});    


					
			$("#name").keydown(function()
			{
					var name = $("#name").val();   
						if(name.length<=0)
						{
						    $("#username").html("You can't leave this empty.");
							
							
						}
						else
						{
							$("#username").html("");
							
						}
			});
			$("#email").keydown(function()
			{
						
							var num = new RegExp("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/");
							var email = $("#email").val(); 
							
							if($("#email").val().length<=0){
								$("#email_error").html("You can't leave this empty.");
								
							}
							else if(!isValid(email)){
								$("#email_error").html("Email is not valid");
								
							}else{
								$("#email_error").html("");
								
							}
							function isValid(email) 
							{
								var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
								//alert( pattern.test(emailAddress) );
								return pattern.test(email);
							};
					
			});
			$("#mobile").keydown(function()
			{
				var mobile = $("#mobile").val();
                var num = new RegExp("[0-9]+");				
						if(mobile.length<=0)
						{
						    $("#mobile_error").html("You can't leave this empty.");
							
						}
						else if(!num.test(mobile))
						{
						  	$("#mobile_error").html("Mobile number is not valid");
							
						}
						else
						{
							$("#mobile_error").html("");
							
						}
			});
			
			$("#room_no").keydown(function()
			{
				var room = $("#room_no").val();
                var num = new RegExp("[0-9]+");				
						if(room.length<=0)
						{
						    $("#room_error").html("You can't leave this empty.");
							
						}
						else if(!num.test(room))
						{
						  	$("#room_error").html("Room number is not valid");
							
						}
						else
						{
							$("#room_error").html("");
							
						}
			});	
			$("#comp_regard").keydown(function()
			{
				var comp = $("#comp_regard").val();
                				
						if(comp.length<=0)
						{
						    $("#complaint_regard").html("You can't leave this empty.");
							
						}
						else
						{
							$("#complaint_regard").html("");
							
						}
			});
			$("#message").keydown(function()
			{
				var msg = $("#message").val();
                				
						if(msg.length<=0)
						{
						    $("#complaint").html("You can't leave this empty.");
							
						}
						else
						{
							$("#complaint").html("");
							
						}
			});
				$(document).ready(function ()
				{   
					
						$("#comp_form").on('submit',(function(e){
						e.preventDefault();
						var name = $("#name").val();
						var email = $("#email").val();
						var mobile = $("#mobile").val();
						var room = $("#room_no").val();
						var comp = $("#comp_regard").val();
						var msg = $("#message").val();
						
						
						if(name.length>0&&email.length>0&&mobile.length>0&&room.length>0&&comp.length>0&&msg.length>0){	
								
								$.ajax({
										url: "complaint_submit.php",
										type: "POST",
										data:  new FormData(this),
										contentType: false,
										cache: false,
										processData:false,	
										success: function(data){
											document.getElementById("comp_form").reset();
											if(data){
											alert(data);
											}
										} 	        
								});
							
						}else{
							$("#username").html("You can't leave this empty.");
							$("#email_error").html("You can't leave this empty.");
							$("#mobile_error").html("You can't leave this empty.");
							$("#room_error").html("You can't leave this empty.");
							$("#complaint_regard").html("You can't leave this empty.");
							 $("#complaint").html("You can't leave this empty.");
							 return false;
						}
						}));
				});	
						
	});
	$(document).ready(function ()
    { 
		$("#old_pass").keydown(function()
				{
					var pswd = 	$("#old_pass").val();
					if(pswd.length<=0){
						$("#oldpswd_error").html("You can't leave this empty.");
						
					}else{
						
						$("#oldpswd_error").html("");
					}
                    				
				
				});
		$("#old_pass").change(function()
				{
							
					var pswd = 	$("#old_pass").val();
										
					if(pswd.length>3)
					{		
						$.ajax({
									
								type: "POST",
								url: "check_oldpswd.php",
								data:"pswd="+ pswd ,
								success: function(data)
								        {
									
   									        if(data)
											{
												$("#oldpswd_error").html(data);
											}
										} 	        
								});
					}						
							
				});
						
							
				
	
		$("#password1").keydown(function()
		{
			if($("#password1").val()<=0){
				
			$("#newpswd_error").html("You can't leave this empty.");	
				
			}else{
				
			$("#newpswd_error").html("");	
				
			}       		
		});
		
		$("#password2").on('blur',function()
		{
			if($("#password1").val() == $("#password2").val()){
				
				$("#pwmatch").removeClass("glyphicon-remove");
				$("#pwmatch").addClass("glyphicon-ok");
				$("#pwmatch").css("color","#00A41E");
			}else{
				
				$("#pwmatch").removeClass("glyphicon-ok");
				$("#pwmatch").addClass("glyphicon-remove");
				$("#pwmatch").css("color","#FF0004");
				
			}
		});
		
	
		

	
		
		
	
	});
	$(document).ready(function ()
    {
		$("#passwordForm").on('submit',(function(e){
						e.preventDefault();
						
						var old_pass = $("#old_pass").val();
						var newpswd1 = $("#password1").val();
						var newpswd2 = $("#password2").val();
						
						
						
						if(old_pass.length>0&&newpswd1.length>0&&newpswd2.length>0)
						{	
								
								$.ajax({
										url: "admin_password_submit.php",
										type: "POST",
										data:  new FormData(this),
										contentType: false,
										cache: false,
										processData:false,	
										success: function(data){
											
											if(data){
											alert(data);
											}
										} 	        
								});
							
						}else{
							$("#oldpswd_error").html("You can't leave this empty.");
							$("#newpswd_error").html("You can't leave this empty.");
							
							
							 return false;
						}
						}));
						
						
						$("#furn_form").on('submit',(function(e){
						e.preventDefault();
						
						var beds = $("#beds").val();		
						var chairs = $("#chairs").val();
						var tables = $("#tables").val();
						
						if(beds.length>0&&chairs.length>0&&tables.length>0)
						{	
								
								$.ajax({
										url: "furniture_update.php",
										type: "POST",
										data:  new FormData(this),
										contentType: false,
										cache: false,
										processData:false,	
										success: function(data){
											//document.getElementById("comp_form").reset();
											if(data){
											alert(data);
											location.reload();
											}
										} 	        
								});
							
						}else{
							$("#beds_error").html("You can't leave this empty.");
							$("#tables_error").html("You can't leave this empty.");
							$("#chairs_error").html("You can't leave this empty.");
							
							
							 return false;
						}
						}));
			$("#beds").keydown(function()
			{
				var beds = $("#beds").val();
                var num = new RegExp("[0-9]+");				
						if(beds.length<=0)
						{
						    $("#beds_error").html("You can't leave this empty.");
							$("#beds").css("border","2px solid #FF0004");
						}
						else if(!num.test(beds))
						{
						  	$("#beds_error").html("Must be a numeric value");
							$("#beds").css("border","2px solid #FF0004");
						}
						else
						{
							
							$("#beds").css("border","2px solid #00A41E");
					        $("#beds_error").html("");
							
						}
			});
			$("#tables").keydown(function()
			{
				var tables = $("#tables").val();
                var num = new RegExp("[0-9]+");				
						if(tables.length<=0)
						{
						    $("#tables_error").html("You can't leave this empty.");
							$("#tables").css("border","2px solid #FF0004");
						}
						else if(!num.test(tables))
						{
						  	$("#tables_error").html("Must be a numeric value");
							$("#tables").css("border","2px solid #FF0004");
						}
						else
						{
							
							$("#tables").css("border","2px solid #00A41E");
					        $("#tables_error").html("");
						}
			});$("#chairs").keydown(function()
			{
				var chairs = $("#chairs").val();
                var num = new RegExp("[0-9]+");				
						if(chairs.length<=0)
						{
						    $("#chairs_error").html("You can't leave this empty.");
							$("#chairs").css("border","2px solid #FF0004");
						}
						else if(!num.test(chairs))
						{
						  	$("#chairs_error").html("Must be a numeric value");
							$("#chairs").css("border","2px solid #FF0004");
						}
						else
						{
							
							$("#chairs").css("border","2px solid #00A41E");
					        $("#chairs_error").html("");
						}
			});
	});	
	
	