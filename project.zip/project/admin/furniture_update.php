   <?php




$con = mysqli_connect("localhost","root","","hostel");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();





$beds = $_POST['beds'];
$tables = $_POST['tables'];
$chairs = $_POST['chairs'];

$qry = "UPDATE `furniture` SET `beds` = '".$beds."', `tables` = '".$tables."', `chairs` = '".$chairs."' WHERE `furniture`.`furniture_id` = 1";
$result=mysqli_query($con,$qry);
if($result){
	
	echo "Updated Successfully";
}else{
	echo "Update Failed";
}
?>