 <?php




$con = mysqli_connect("localhost","root","","hostel");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();
?> 

<?php

$pswd = $_POST['pswd'];
$username = $_SESSION["user_name"];

$result = mysqli_query($con,"SELECT `username` FROM `admin` WHERE `username`='".$username."' and `password`='".$pswd."'");
$row = mysqli_fetch_row($result);
if($row){
	
	echo 'Matched';
}else{
	
	echo 'Not Matched';
}



?>
