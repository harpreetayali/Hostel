<?php include("header_admin.php");?>


<?php

$info = mysqli_query($con,"SELECT * FROM `complaint`");
						


?>
<?php if(isset($_SESSION['user_id']))
		{   ?>
				<div class="wrapper">
				   <div class="sidebar" data-color="brown" data-image="img/hostel_path_sidebar3.jpg">

					<!--   you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple" -->


						<div class="sidebar-wrapper">
							<div class="logo">
								<a href="" class="simple-text">
									Admin Panel
								</a>
							</div>

							<ul class="nav">
								<li>
									<a href="index.php">
										<i class="pe-7s-graph"></i>
										<p>Dashboard</p>
									</a>
								</li>
								<li >
									<a href="update_data.php">
										<i class="pe-7s-user"></i>
										<p>Update Data</p>
									</a>
								</li>
								<li class="active">
									<a href="complaints.php">
										<i class="pe-7s-note2"></i>
										<p>Complaints</p>
									</a>
								</li>
								<li>
									<a href="furniture.php">
										<i class="pe-7s-note2"></i>
										<p>Furniture</p>
									</a>
								</li>
								<li>
									<a href="change_password.php">
										<i class="pe-7s-news-paper"></i>
										<p>Change Password</p>
									</a>
								</li>
								
								
							</ul>
						</div>
					</div>

					<div class="main-panel">
						<nav class="navbar navbar-default navbar-fixed">
							<div class="container-fluid">
								<div class="navbar-header">
								   
									<a class="navbar-brand" href="#">Complaints</a>
								</div>
								<div class="collapse navbar-collapse">
									

									<ul class="nav navbar-nav navbar-right">
										
										<li>
											<a href="logout.php">
												<p>Log out</p>
											</a>
										</li>
										<li class="separator hidden-lg hidden-md"></li>
									</ul>
								</div>
							</div>
						</nav>

						<div class="content">
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-12">
										<div class="card">
											
											<div class="content table-responsive table-full-width">
												<table class="table table-hover table-striped">
													<thead>
														<th>ID</th>
														<th>Name</th>
														<th>Email</th>
														<th>Mobile</th>
														<th>Room NO</th>
														<th>Complaint Regard</th>
														<th>Complaint</th>
													</thead>
													<tbody>
													<?php
													$i = 0;
													while ($complaint_detail = mysqli_fetch_array($info, MYSQLI_ASSOC))   
													{ 
													$i++;
													?>
														<tr>
															<td><?=$i?></td>
															<td><?=$complaint_detail['name']?></td>
															<td><?=$complaint_detail['email']?></td>
															<td><?=$complaint_detail['mobile']?></td>
															<td><?=$complaint_detail['room_no']?></td>
															<td><?=$complaint_detail['complaint_regard']?></td>
															<td><?=$complaint_detail['complaint']?></td>
														</tr>
													<?php
													}
													?>    
													</tbody>
												</table>

											</div>
										</div>
									</div>


									


								</div>
							</div>
						</div>

						


					</div>
				</div>

		<?php 
		}
		?>
