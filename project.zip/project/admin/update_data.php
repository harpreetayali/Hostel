<?php include("header_admin.php");?>

<?php if(isset($_SESSION['user_id']))
		{   ?>
					<div class="wrapper">
						<div class="sidebar" data-color="brown" data-image="img/hostel_entry_sidebar2.jpg">

					   

							<div class="sidebar-wrapper">
								<div class="logo">
									<a href="" class="simple-text">
										Admin Panel
									</a>
								</div>

								<ul class="nav">
									<li>
										<a href="index.php">
											<i class="pe-7s-graph"></i>
											<p>Dashboard</p>
										</a>
									</li>
									<li class="active">
										<a href="update_data.php">
											<i class="pe-7s-user"></i>
											<p>Update Data</p>
										</a>
									</li>
									<li>
										<a href="complaints.php">
											<i class="pe-7s-note2"></i>
											<p>Complaints</p>
										</a>
									</li>
									<li>
									<a href="furniture.php">
										<i class="pe-7s-note2"></i>
										<p>Furniture</p>
									</a>
								    </li>
									<li>
										<a href="change_password.php">
											<i class="pe-7s-news-paper"></i>
											<p>Change Password</p>
										</a>
									</li>
									
									
								</ul>
							</div>
						</div>

						<div class="main-panel">
							<nav class="navbar navbar-default navbar-fixed">
								<div class="container-fluid">
									<div class="navbar-header">
										<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
											<span class="sr-only">Toggle navigation</span>
											<span class="icon-bar"></span>
											<span class="icon-bar"></span>
											<span class="icon-bar"></span>
										</button>
										<a class="navbar-brand" href="#">Updation</a>
									</div>
									<div class="collapse navbar-collapse">
										

										<ul class="nav navbar-nav navbar-right">
											
											<li>
												<a href="logout.php">
													<p>Log out</p>
												</a>
											</li>
											<li class="separator hidden-lg hidden-md"></li>
										</ul>
									</div>
								</div>
							</nav>


							<div class="content">
								
									<div class="row">
										
											<div class="card">
												<div class="header">
													<h4 class="title">Update Registered Students</h4>
												</div>
												<div class="content">
													<table class="table table-hover table-striped">
													<thead>
														<th>ID</th>
														<th>Room</th>
														<th>Name</th>
														<th>Roll No</th>
														<th>Class</th>
														<th>Currently Available</th>
														
													</thead>
													<tbody>
													<?php
													$info = mysqli_query($con,"SELECT * FROM `registration`");
													$i = 0;
													while($student_detail = mysqli_fetch_array($info, MYSQLI_ASSOC))
													{														
													$i++;
													
													?>
														<tr>
															<td><?=$i?></td>
															<td><?=$student_detail['room']?></td>
															<td><?=$student_detail['student_name']?></td>
															<td><?=$student_detail['roll_no']?></td>
															<td><?=$student_detail['class']?></td>
															<td><?=$student_detail['available']?></td>
															
														    <td><button class="update_btn"id="">Edit Profile</button></td>
														</tr>
													<?php
													   
													}
													?>
													</tbody>
												</table>	

												</div>
											</div>
									</div>
										

							</div>
								



						</div>
					</div>


		<?php 
		}
		?>