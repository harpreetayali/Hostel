    <?php 
	include("header.php");
	$row = mysqli_query($con,"select reg_id from registration ORDER BY reg_id DESC");
		
	$reg_no = mysqli_fetch_array($row);


	
	
	?>            			
        
  			<h1 class="text-center text-color">GURU NANAK DEV POLYTECHNIC COLLEGE</h1>
			<p id="error" class="text-color" ></p>
			
			    <div class="container" style="margin-top: 25px;">
					<div class="row">
					
					
						<div class="col-md-8">
								
							<h4 class="heading"><strong>Registration </strong> Form  GNDPC #00<?=$reg_no['reg_id']+1?> <span id="date"></span></h4>
							
							<div class="form">
		
			
			<table>
				
				<form action="submit.php" method="post" onsubmit="return validation(this)" id="contactFrm"  name="contactFrm" enctype="multipart/form-data" >
							
						<tr>
							<td><label>Name of Student<span style="color:red;">*</span></label></td>	
							<td><input type="text"  name="name"  placeholder="Enter your Name"  class="txt"></td>
							 <td><label>Course<span style="color:red;">*</span></label></td>
							<td><select name="block" class="course" style="margin-left: 8px;">
							<option value="">Select An option</option>
							<option value="Diploma">Diploma</option>
							<option value="B.Tech">B.Tech</option>
							<option value="M.Tech">M.Tech</option>
							<option value="MCA">MCA</option>
							<option value="MBA">MBA</option>
							
							</select></td>
							<td></td>
                        </tr>
							
							
						 
						<tr> 	
						<tr>
							<td><label>Roll no.<span style="color:red;">*</span></label></td>
							<td><input type="text"  name="roll_no" placeholder="Enter your Roll no."  class="txt" /></td>
                           <td><label>Class<span style="color:red;">*</span></label></td>
							<td><input type="text" name="class" placeholder="Enter your class"  class="txt" /></td>
						
						
						
						</tr>    
						<tr> 
							<td><label>Father's Name<span style="color:red;">*</span></label></td>
						    <td><input type="text" name="f_name" placeholder="Enter your father name"  class="txt" /></td>
						    
							<td><label>Father occupation<span style="color:red;">*</span></label></td>
		       		        <td><input type="text"  name="f_occupation" placeholder="Occupation"  class="txt" /></td>
							
						</tr>
                            
						<tr> 	
						
						     <td><label>Student's Email<span style="color:red;">*</span></label></td>
						     <td><input type="text" name="s_email" placeholder="Enter your Email"  class="txt" /></td>
						
							<td><label>Parent's Email</label></td>
  						     <td><input type="text"  name="p_email" placeholder="Enter parent's Email"  class="txt" /></td>
                        
						</tr>
							
						<tr>		
    					<td><label>Student's(M)Ph. No.<span style="color:red;">*</span></label></td>
				        <td><input type="text" name="s_m_no" placeholder="Enter your Mobile no."  class="txt" /></td>
						
						<td><label>Father's Landline No.</label></td>
						<td><input type="text" name="f_l_no" placeholder="Enter your Father's Landline no."  class="txt" /></td>
						</tr>
							
						<tr>							
						   	<td><label>Father's(M)Ph. No.<span style="color:red;">*</span></label></td>
							<td><input type="text" name="f_m_no" placeholder="Enter your Father's Mobile no."  class="txt" /></td>
                        
    						
							<td><label>Blood Group<span style="color:red;">*</span></label></td>
							<td><select name="blood_group" class="blood_grp">
							<option value="">Select Blood Group</option>
							<option value="A+">A+</option>
							<option value="A-">A-</option>
							<option value="B+">B+</option>
							<option value="B-">B-</option>
							<option value="AB+">AB+</option>
							<option value="AB-">AB-</option>
							<option value="O+">O+</option>
							<option value="O-">O-</option>
							</select>
							</td>
							
							
							
						</tr>
							
     					<tr>
                            <td><label>Fee receipt no.<span style="color:red;">*</span></label></td>
							<td><input type="text" name="receipt_no" placeholder="Enter your receipt no."  class="txt">	</td>
                            
							<td><label>Amount(Rs.)<span style="color:red;">*</span></label></td>
                            <td><input type="text"  name="amount" placeholder="Enter the amount"  class="txt"></td> 						
	                          
                        </tr>
						<tr>
							<td><label>Room type<span style="color:red;">*</span></label></td>
							
					<td> 
						
						<input type="radio" name="attached_rooms" value="single"   class="txt" /><label>Single</label><br>
						
						<input type="radio" name="attached_rooms" value="no"   class="txt" /><label>Shared(3)</label><br>
												
						<input type="radio" name="attached_rooms" value="yes"   class="txt" /><label>Attached bathroom</label>
						
						
					</td>
					<td>
						
					</td>
					<td>
				  
						
					</td>

						</tr>   
							
							
                         	
					<tr>
						<td></td><td></td>
						<td>
						   <input type="submit" value="  NEXT"  name="submit" onclick="display()" class="txt2">
						</td>
                    </tr>							
												
																	
																		
																		
																		
				</form>
					
						</table>
									</div>
								
						</div>
							<div class="col-md-4">

							<div id="display-error"  style="margin-top: 82px;">  </div>
							</div>
							
						</div>
					</div>
						
					
		<script>
		   function validation(form){
		   

           var mailformat=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		   var errors=[];
		   if(form.name.value == ""){
		   errors.push("Name of Student is Empty!");
		   }
		   if (form.block.value == "") {
				 errors.push("Course is not selected");
				  	}
				
		   if(form.roll_no.value == ""){
		   errors.push("Roll no is empty!");		   
		   }
		   
		   if (isNaN(form.roll_no.value) )  
              {  
             errors.push("Roll no. is not valid"); 

                }
		   if(form.class.value == ""){
		   errors.push("Class  is empty!");
		   
		   } 
		   if(form.f_name.value == ""){
		   errors.push("Father name is empty!")
		   }
		   if(form.f_occupation.value == ""){
		   errors.push("Father occupation is empty!")
		   }
		    if(form.s_email.value == ""){
		   errors.push("Email is empty!");
		   
		   }else if (form.s_email.value.match(mailformat))  
              { 
                
                } else{ 
             errors.push("You have entered an invalid email address!"); 

                }
		   if(form.s_m_no.value == ""){
		   errors.push("Mobile no. is empty!")
		   }
		   if(isNaN(form.s_m_no.value)){
		   
		   
		   errors.push("Mobile no. is not valid")
		   }
		   if(form.f_m_no.value == ""){
		   errors.push("Father's mobile no. is empty!")
		   }
		   if( isNaN(form.f_m_no.value)){
		   
		    errors.push("Father's Mobile no. is not valid")
		   }
		   
		   if(form.receipt_no.value == ""){
		   errors.push("Receipt no. is empty!");
           }
		   if(isNaN(form.receipt_no.value)){
		    errors.push("Receipt no. is not valid")
		   }
		   if(form.amount.value == ""){
		   errors.push("Amount is empty!")
		   }
		   if(isNaN(form.amount.value)){
		   		   
		   errors.push("Amount is not valid!")
		   
		   }
		   if(form.attached_rooms.value == ""){
		   errors.push("Room type is not selected!")
		   }
		   
		   		  
		   if(errors.length>0){
		   var msg="ERRORS:\n\n";
		   for(i=0;i<errors.length;i++){
		   msg += errors[i]+ "<br><br>";
		   }
		   
		  document.getElementById("display-error").innerHTML = msg;
		    return false;
		   }
		   
		   }
		   function display(){
		   $("#display-error").show();
		   }
		   
		   
		   
				

		var d = new Date();
				document.getElementById("date").innerHTML = d.toDateString();
		</script>
				
					
                    				
											 
			 <?php include("footer.php");?>			
				
                
            				
       