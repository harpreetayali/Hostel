		
  			
		<?php include("header.php");?>	
				
                			
        <h1 class="hostel-head ">Hostel</h1 >
		<div class="row" >
             	    <div class="col-md-2 col-sm-2">
                    </div> 	
            <div class="col-md-8 col-sm-8">
			     
  
					<div id="myCarousel" class="carousel slide" data-ride="carousel">
						
						<ol class="carousel-indicators">
						  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
						  <li data-target="#myCarousel" data-slide-to="1"></li>
						  <li data-target="#myCarousel" data-slide-to="2"></li>
						  
						</ol>

					
						<div class="carousel-inner" role="listbox">
						 
						 <div class="item active">
							<img class="slider-margin img-responsive" src="img/hostel_entry.jpg" width="460" height="345">
						  </div> 
						  
						  <div class="item ">
							<img class="slider-margin img-responsive" src="img/entry.jpg" width="460" height="345">
						  </div>	
						  
						  <div class="item ">
							<img class="slider-margin img-responsive" src="img/club.jpg" width="460" height="345">
						  </div>	
								
						</div>

						
						<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
						  <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						  <span class="sr-only">Previous</span>
						</a>
						<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
						  <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						  <span class="sr-only">Next</span>
						</a>
					</div>
			     
			</div>
                
						
			<div class="col-md-2 col-sm-2">
			</div> 
	    </div>
			
                  
			<div class="row">
				  <div class="col-sm-3">
				  </div>
				<div class="col-sm-6">
					<h1 class="txt-center"><strong class="text-color">Why GNDPC Hostel</strong></h1>
				    <p class="txt-center">GNDPC hostel provides best security and environment</p>
					
					<div class="row">
						
						<div class="col-sm-4 txt-center">
						   <img src="img/fa-bed.png" />
						   <h3 class="text-color">Good Rooms</h3>
						</div>
						
						<div class="col-sm-4">					  
						</div>
						  
						<div class="col-sm-4 txt-center">
						  
						  <img src="img/fa-food.png " />
						  <h3 class="text-color">Healthy Food</h3>
						</div>				
						
				    </div>
				</div>
                  <div class="col-sm-3">
				  </div>				
				
			</div>
			
              
	  <?php include("footer.php");?>	