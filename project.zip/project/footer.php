
		<footer class="row " style=" background-color: rgb(128, 0, 0);">
					<div class="col-md-2 col-sm-2">
					</div> 	
						<div class="col-md-8 col-sm-8 footer bcgrnd">				
							<h4>Contact Us</h4>
								
							 <p><img src="img/fa-mob.png">0161-2504053</p>
						     <p><img src="img/fa-email.png">email@gmail.com</p>
									
						</div>
						<div class="col-md-2 col-sm-2">
						</div>		
			    </footer>	
		   	
		